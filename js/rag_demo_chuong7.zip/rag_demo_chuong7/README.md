# RAG Demo – Chương 7

Demo phục vụ thuyết trình về Retrieval-Augmented Generation (RAG).

## Luồng

```text
PDF/TXT
  ↓
Load documents
  ↓
Chunking
  ↓
Embedding
  ↓
FAISS Vector Index
  ↓
User question
  ↓
Similarity Search / Top-k
  ↓
Context
  ↓
LLM
  ↓
Answer + Source
```

## Chạy

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

Lần đầu chạy `sentence-transformers` sẽ tải model embedding.

## Demo trên lớp

### Bước 1 – Tài liệu
Upload 3–5 PDF/TXT, ví dụ:
- chính sách bảo hành
- chính sách đổi trả
- hướng dẫn sản phẩm

### Bước 2 – Chunk
Cho sinh viên xem:
- số file
- số chunk
- chunk mẫu
- metadata

### Bước 3 – Retrieval
Hỏi:
> Sản phẩm được bảo hành trong bao lâu?

Cho sinh viên nhìn **Top-k chunks trước khi gọi LLM**.

### Bước 4 – LLM
Nhập OpenAI API key nếu muốn chạy phần sinh câu trả lời.

### Bước 5 – Thí nghiệm
Thử:
- chunk size: 200 → 500 → 1000
- top-k: 1 → 3 → 5

Quan sát context thay đổi như thế nào.

## Gợi ý 3 câu hỏi demo

1. Sản phẩm được bảo hành trong bao lâu?
2. Trường hợp nào không được bảo hành?
3. Tôi có thể đổi sản phẩm trong bao nhiêu ngày?

## Điểm cần nói khi thuyết trình

- Chunking quyết định "đơn vị kiến thức" mà hệ thống tìm kiếm.
- Embedding biến văn bản và câu hỏi thành vector.
- Similarity search tìm những chunk gần câu hỏi nhất.
- Top-k là số lượng chunk được lấy làm context.
- LLM không tự tìm tài liệu; nó nhận context từ retriever rồi tạo câu trả lời.
- Metadata giúp truy xuất nguồn và giải thích câu trả lời.
