import os
from pathlib import Path
import hashlib
import streamlit as st
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

st.set_page_config(page_title="RAG Demo - Chương 7", page_icon="🔎", layout="wide")

st.title("🔎 RAG Demo – Kịch bản Chương 7")
st.caption("Demo nhỏ nhưng thể hiện đầy đủ: documents → chunking → embedding → retrieval → context → LLM → nguồn.")

# ---------- Helpers ----------
@st.cache_resource
def get_embedder():
    return SentenceTransformer("all-MiniLM-L6-v2")

def read_txt(path):
    return Path(path).read_text(encoding="utf-8", errors="ignore")

def read_pdf(path):
    reader = PdfReader(path)
    return "\n".join((p.extract_text() or "") for p in reader.pages)

def load_documents(uploaded_files):
    docs = []
    for f in uploaded_files:
        suffix = Path(f.name).suffix.lower()
        raw = f.getvalue()
        if suffix == ".pdf":
            tmp = Path("/tmp") / f.name
            tmp.write_bytes(raw)
            text = read_pdf(tmp)
        else:
            text = raw.decode("utf-8", errors="ignore")
        docs.append({"file": f.name, "text": text})
    return docs

def chunk_text(text, chunk_size=500, overlap=100):
    text = " ".join(text.split())
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = min(len(text), start + chunk_size)
        chunk = text[start:end]
        chunks.append(chunk)
        if end == len(text):
            break
        start = max(end - overlap, start + 1)
    return chunks

def build_index(docs, chunk_size, overlap):
    rows = []
    for d in docs:
        chunks = chunk_text(d["text"], chunk_size, overlap)
        for i, chunk in enumerate(chunks):
            rows.append({
                "id": len(rows),
                "file": d["file"],
                "chunk_id": i,
                "text": chunk,
                "metadata": {
                    "source": d["file"],
                    "chunk_id": i,
                    "chars": len(chunk)
                }
            })

    if not rows:
        return None, []

    model = get_embedder()
    embeddings = model.encode(
        [r["text"] for r in rows],
        normalize_embeddings=True,
        show_progress_bar=False
    ).astype("float32")

    index = faiss.IndexFlatIP(embeddings.shape[1])
    index.add(embeddings)
    return index, rows

def retrieve(question, index, rows, top_k):
    model = get_embedder()
    q = model.encode([question], normalize_embeddings=True).astype("float32")
    scores, ids = index.search(q, min(top_k, len(rows)))
    results = []
    for score, idx in zip(scores[0], ids[0]):
        if idx < 0:
            continue
        item = dict(rows[idx])
        item["score"] = float(score)
        results.append(item)
    return results

def answer_with_llm(question, results, api_key, model_name):
    context = "\n\n".join(
        f"[Nguồn: {r['file']} | chunk {r['chunk_id']}]\n{r['text']}"
        for r in results
    )
    prompt = f"""Bạn là trợ lý hỏi đáp dựa trên tài liệu.
Chỉ trả lời dựa trên CONTEXT. Nếu không đủ thông tin, nói rõ "Không tìm thấy thông tin trong tài liệu".
Luôn ghi nguồn ở cuối câu trả lời theo dạng [Nguồn: tên_file, chunk N].

CÂU HỎI:
{question}

CONTEXT:
{context}
"""
    if not OpenAI:
        return "Chưa cài thư viện OpenAI."
    client = OpenAI(api_key=api_key)
    resp = client.chat.completions.create(
        model=model_name,
        messages=[
            {"role": "system", "content": "Bạn trả lời chính xác, ngắn gọn và không bịa thông tin."},
            {"role": "user", "content": prompt},
        ],
        temperature=0
    )
    return resp.choices[0].message.content

# ---------- Sidebar ----------
st.sidebar.header("⚙️ Cấu hình")
chunk_size = st.sidebar.slider("Chunk size", 200, 1200, 500, 50)
overlap = st.sidebar.slider("Chunk overlap", 0, 300, 100, 25)
top_k = st.sidebar.slider("Top-k", 1, 10, 3)

st.sidebar.divider()
api_key = st.sidebar.text_input("OpenAI API key (tùy chọn)", type="password")
model_name = st.sidebar.text_input("LLM model", value="gpt-4o-mini")

st.sidebar.info(
    "Có thể chạy phần retrieval mà không cần API key. "
    "Muốn sinh câu trả lời bằng LLM thì nhập API key."
)

# ---------- Documents ----------
st.subheader("1️⃣ Chuẩn bị tài liệu")
uploads = st.file_uploader(
    "Upload 3–5 file PDF/TXT",
    type=["pdf", "txt"],
    accept_multiple_files=True
)

if uploads:
    docs = load_documents(uploads)
else:
    docs = [
        {"file": "chinh_sach_bao_hanh.txt", "text":
         "Sản phẩm được bảo hành 12 tháng kể từ ngày mua. "
         "Bảo hành áp dụng cho lỗi kỹ thuật do nhà sản xuất. "
         "Không bảo hành các hư hỏng do rơi vỡ, vào nước hoặc tự ý sửa chữa."},
        {"file": "chinh_sach_doi_tra.txt", "text":
         "Khách hàng có thể đổi sản phẩm trong vòng 7 ngày kể từ ngày nhận hàng. "
         "Sản phẩm phải còn nguyên tình trạng ban đầu, đầy đủ phụ kiện và hóa đơn. "
         "Phí vận chuyển đổi trả do khách hàng chịu, trừ trường hợp sản phẩm bị lỗi."},
        {"file": "huong_dan_san_pham.txt", "text":
         "Thiết bị có thời lượng pin khoảng 10 giờ trong điều kiện sử dụng tiêu chuẩn. "
         "Để sạc, sử dụng bộ sạc USB-C đi kèm. Đèn màu xanh báo hiệu pin đã đầy. "
         "Không sử dụng thiết bị trong môi trường có nước hoặc độ ẩm cao."},
    ]

st.write(f"**Số file:** {len(docs)}")
for d in docs:
    st.write(f"- `{d['file']}` — {len(d['text']):,} ký tự")

# ---------- Build ----------
if st.button("🔨 Build / Rebuild Vector Index", type="primary"):
    with st.spinner("Đang chunk + embedding + build FAISS index..."):
        index, rows = build_index(docs, chunk_size, overlap)
    st.session_state["index"] = index
    st.session_state["rows"] = rows
    st.session_state["config"] = (chunk_size, overlap)
    st.success(f"Đã tạo {len(rows)} chunks.")

if "index" not in st.session_state:
    with st.spinner("Đang tạo index mặc định..."):
        index, rows = build_index(docs, chunk_size, overlap)
    st.session_state["index"] = index
    st.session_state["rows"] = rows
    st.session_state["config"] = (chunk_size, overlap)

index = st.session_state["index"]
rows = st.session_state["rows"]

# ---------- Stats ----------
st.subheader("2️⃣ Quan sát dữ liệu đã chunk")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Số file", len(docs))
c2.metric("Số chunk", len(rows))
c3.metric("Chunk size", chunk_size)
c4.metric("Top-k", top_k)

with st.expander("Xem chunk mẫu + metadata"):
    for r in rows[:5]:
        st.markdown(
            f"**chunk {r['chunk_id']} — {r['file']}**  \n"
            f"metadata: `{r['metadata']}`  \n"
            f"> {r['text']}"
        )

# ---------- QA ----------
st.subheader("3️⃣ Hỏi đáp RAG")
question = st.text_input(
    "Nhập câu hỏi",
    value="Sản phẩm được bảo hành trong bao lâu?"
)

if st.button("🔎 Retrieve + Answer"):
    if not question.strip():
        st.warning("Hãy nhập câu hỏi.")
    else:
        with st.spinner("Đang retrieval..."):
            results = retrieve(question, index, rows, top_k)

        st.markdown("### Top-k chunks trước khi gọi LLM")
        for rank, r in enumerate(results, 1):
            st.markdown(
                f"**#{rank} — score={r['score']:.4f} — "
                f"{r['file']} / chunk {r['chunk_id']}**"
            )
            st.code(r["text"], language="text")

        st.divider()
        if api_key:
            with st.spinner("Đang gọi LLM..."):
                answer = answer_with_llm(question, results, api_key, model_name)
            st.markdown("### 🤖 Câu trả lời có nguồn")
            st.write(answer)
        else:
            st.markdown("### 🤖 Câu trả lời dự kiến")
            st.info(
                "Chưa nhập API key nên demo dừng ở retrieval. "
                "Top-k chunks ở trên chính là CONTEXT sẽ được gửi cho LLM."
            )

# ---------- Experiment ----------
st.subheader("4️⃣ Thí nghiệm: thay đổi chunk size / top-k")
st.markdown(
    "Giữ nguyên câu hỏi rồi thử **chunk size = 200/500/1000** hoặc "
    "**top-k = 1/3/5**. Quan sát số chunk, nội dung chunk và chất lượng context."
)
